let noSleep;

// Initialize noSleep when needed
async function initNoSleep() {
    if (!noSleep) {
        try {
            noSleep = new NoSleep();
            await noSleep.enable();
            console.log("Wake lock enabled");
        } catch (error) {
            console.error("Failed to initialize NoSleep:", error);
            // Create a fallback with empty methods
            noSleep = {
                enable: () => console.log("Wake lock not available"),
                disable: () => console.log("Wake lock not available")
            };
        }
    }
}

// Sound objects
let tickSound, buttonSound, warningSound;
let buttonSoundPlaying = false; // Flag to prevent multiple button sounds

// Load sound effects - using simpler sounds with lower volume
function loadSounds() {
    try {
        tickSound = new Audio('https://assets.mixkit.co/active_storage/sfx/2006/2006-preview.mp3');
        tickSound.volume = 0.1;
        
        buttonSound = new Audio('https://assets.mixkit.co/active_storage/sfx/270/270-preview.mp3');
        buttonSound.volume = 0.2;
        
        warningSound = new Audio('https://assets.mixkit.co/active_storage/sfx/1862/1862-preview.mp3');
        warningSound.volume = 0.3;
    } catch (error) {
        console.error("Failed to load sounds:", error);
    }
}

// Load sounds when document is ready
document.addEventListener('DOMContentLoaded', loadSounds);

// DOM elements
const settingsPanel = document.querySelector('.settings-panel');
const chessClockPanel = document.querySelector('.chess-clock');
const playerOne = document.querySelector('.player-one');
const playerTwo = document.querySelector('.player-two');
const playerOneTime = playerOne.querySelector('.time');
const playerTwoTime = playerTwo.querySelector('.time');
const playerBtns = document.querySelectorAll('.player-btn');
const startBtn = document.getElementById('start-btn');
const pauseBtn = document.getElementById('pause-btn');
const resetBtn = document.getElementById('reset-btn');
const settingsBtn = document.getElementById('settings-btn');
const controls = document.querySelector('.controls');
const minutesInput = document.getElementById('minutes');
const incrementInput = document.getElementById('increment');
const playerOneNameInput = document.getElementById('player-one-name');
const playerTwoNameInput = document.getElementById('player-two-name');
const playerOneColorSelect = document.getElementById('player-one-color');
const playerTwoColorSelect = document.getElementById('player-two-color');
const playerOneNameDisplay = playerOne.querySelector('.player-name');
const playerTwoNameDisplay = playerTwo.querySelector('.player-name');
const playerOneColorDisplay = playerOne.querySelector('.player-color');
const playerTwoColorDisplay = playerTwo.querySelector('.player-color');

// Game state variables
let playerOneTimeInSeconds;
let playerTwoTimeInSeconds;
let increment;
let activePlayer = null;
let timerInterval = null;
let isPaused = false;
let moveCount = 0;
let playerOneName = "Jugador 1";
let playerTwoName = "Jugador 2";
let playerOneColor = "white";
let playerTwoColor = "black";

// Synchronize player colors
playerOneColorSelect.addEventListener('change', () => {
    const selectedColor = playerOneColorSelect.value;
    playerTwoColorSelect.value = selectedColor === 'white' ? 'black' : 'white';
});

playerTwoColorSelect.addEventListener('change', () => {
    const selectedColor = playerTwoColorSelect.value;
    playerOneColorSelect.value = selectedColor === 'white' ? 'black' : 'white';
});

// Initialize the game
async function initGame() {
    await initNoSleep();
    const minutes = parseInt(minutesInput.value) || 10;
    increment = parseInt(incrementInput.value) || 0;
    
    playerOneTimeInSeconds = minutes * 60;
    playerTwoTimeInSeconds = minutes * 60;
    
    // Get player names and colors
    playerOneName = playerOneNameInput.value || "Jugador 1";
    playerTwoName = playerTwoNameInput.value || "Jugador 2";
    playerOneColor = playerOneColorSelect.value;
    playerTwoColor = playerTwoColorSelect.value;
    
    // Update player info displays with correct chess piece icons
    playerOneNameDisplay.textContent = playerOneName;
    playerTwoNameDisplay.textContent = playerTwoName;
    playerOneColorDisplay.textContent = playerOneColor === 'white' ? '♙ Blancas' : '♟ Negras';
    playerTwoColorDisplay.textContent = playerTwoColor === 'white' ? '♙ Blancas' : '♟ Negras';
    
    updateDisplayTime(playerOneTime, playerOneTimeInSeconds);
    updateDisplayTime(playerTwoTime, playerTwoTimeInSeconds);
    
    settingsPanel.classList.add('hidden');
    chessClockPanel.classList.remove('hidden');
    // Don't show controls yet, they will appear when a player makes the first move
}

// Update the display time with the correct format
function updateDisplayTime(element, timeInSeconds) {
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = timeInSeconds % 60;
    element.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    
    // Add warning class if time is less than 30 seconds
    if (timeInSeconds <= 30) {
        element.classList.add('time-warning');
        // Play warning sound only at certain thresholds to reduce resource usage
        if ([30, 20, 10, 5].includes(timeInSeconds) && warningSound) {
            try {
                warningSound.play().catch(err => console.log('Warning sound play error:', err));
            } catch (error) {
                console.error("Failed to play warning sound:", error);
            }
        }
    } else {
        element.classList.remove('time-warning');
    }
}

// Start the timer for the current player
function startTimer() {
    if (timerInterval) clearInterval(timerInterval);
    
    timerInterval = setInterval(() => {
        if (activePlayer === 1) {
            playerOneTimeInSeconds--;
            updateDisplayTime(playerOneTime, playerOneTimeInSeconds);
            
            if (playerOneTimeInSeconds <= 0) {
                gameOver(2);
            } else if (playerOneTimeInSeconds % 5 === 0 && tickSound) { // Play tick sound less frequently
                try {
                    tickSound.play().catch(err => console.log('Tick sound play error:', err));
                } catch (error) {
                    console.error("Failed to play tick sound:", error);
                }
            }
        } else if (activePlayer === 2) {
            playerTwoTimeInSeconds--;
            updateDisplayTime(playerTwoTime, playerTwoTimeInSeconds);
            
            if (playerTwoTimeInSeconds <= 0) {
                gameOver(1);
            } else if (playerTwoTimeInSeconds % 5 === 0 && tickSound) { // Play tick sound less frequently
                try {
                    tickSound.play().catch(err => console.log('Tick sound play error:', err));
                } catch (error) {
                    console.error("Failed to play tick sound:", error);
                }
            }
        }
    }, 1000);
}

// Play button sound with debounce to prevent multiple sounds
function playButtonSound() {
    if (!buttonSound || buttonSoundPlaying) return;
    
    buttonSoundPlaying = true;
    try {
        // Reset current time to start from beginning every time
        buttonSound.currentTime = 0;
        buttonSound.play()
            .then(() => {
                setTimeout(() => {
                    buttonSoundPlaying = false;
                }, 300); // Increased debounce period to prevent rapid firing
            })
            .catch(err => {
                console.log('Button sound play error:', err);
                buttonSoundPlaying = false;
            });
    } catch (error) {
        console.error("Failed to play button sound:", error);
        buttonSoundPlaying = false;
    }
}

// Switch to the other player
function switchPlayer(player) {
    if (isPaused) return;
    
    // Only play button sound if action is valid to prevent multiple sounds
    if ((activePlayer === player || activePlayer === null)) {
        playButtonSound();
    }
    
    // Add increment for the player who just completed their move (clicked their button)
    if (activePlayer === player) {
        if (player === 1) {
            playerOneTimeInSeconds += increment;
            updateDisplayTime(playerOneTime, playerOneTimeInSeconds);
        } else if (player === 2) {
            playerTwoTimeInSeconds += increment;
            updateDisplayTime(playerTwoTime, playerTwoTimeInSeconds);
        }
        moveCount++;
        
        // Switch to the opposite player
        activePlayer = player === 1 ? 2 : 1;
    } else if (activePlayer === null) {
        // First move of the game
        activePlayer = player;
        // Show controls when the game actually starts
        controls.classList.remove('hidden');
    } else {
        // Wrong player clicked - ignore
        return;
    }
    
    // Update UI - make sure inactive player's button is visually blocked
    if (activePlayer === 1) {
        playerOne.classList.add('active');
        playerOne.classList.remove('inactive');
        playerTwo.classList.add('inactive');
        playerTwo.classList.remove('active');
    } else {
        playerTwo.classList.add('active');
        playerTwo.classList.remove('inactive');
        playerOne.classList.add('inactive');
        playerOne.classList.remove('active');
    }
    
    startTimer();
}

// Handle game over
function gameOver(winner) {
    clearInterval(timerInterval);
    const winnerName = winner === 1 ? playerOneName : playerTwoName;
    alert(`${winnerName} gana! Total de movimientos: ${moveCount}`);
    resetGame();
}

// Reset the game
function resetGame() {
    clearInterval(timerInterval);
    activePlayer = null;
    isPaused = false;
    moveCount = 0;
    
    playerOne.classList.remove('active', 'inactive');
    playerTwo.classList.remove('active', 'inactive');
    
    pauseBtn.textContent = '⏸️';
    
    chessClockPanel.classList.add('hidden');
    controls.classList.add('hidden');
    settingsPanel.classList.remove('hidden');
    
    // Disable wake lock when game ends
    try {
        if (noSleep) noSleep.disable();
    } catch (error) {
        console.error("Failed to disable NoSleep:", error);
    }
    
    // Reset controls position to bottom
    controls.classList.remove('top');
}

// Toggle pause
function togglePause() {
    if (!activePlayer) return;
    
    isPaused = !isPaused;
    
    if (isPaused) {
        clearInterval(timerInterval);
        pauseBtn.textContent = '▶️';
    } else {
        startTimer();
        pauseBtn.textContent = '⏸️';
    }
}

// Event listeners
startBtn.addEventListener('click', () => {
    initGame();
    // Controls are now centered, so no need to adjust position
});

playerBtns[0].addEventListener('click', () => {
    // Player 1 clicks their button to stop their clock and start player 2's clock
    if (!isPaused && (activePlayer === 1 || activePlayer === null)) {
        switchPlayer(1);
    }
});

playerBtns[1].addEventListener('click', () => {
    // Player 2 clicks their button to stop their clock and start player 1's clock
    if (!isPaused && (activePlayer === 2 || activePlayer === null)) {
        switchPlayer(2);
    }
});

pauseBtn.addEventListener('click', togglePause);
resetBtn.addEventListener('click', resetGame);
settingsBtn.addEventListener('click', resetGame);